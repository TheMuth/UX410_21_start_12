sap.ui.define([
	"studentXX/sap/training/ex_12dynamicpage/test/unit/controller/App.controller"
], function () {
	"use strict";
});
